# AI Script for Step 3
print('Executing Step 3...')