# AI Script for Step 4
print('Executing Step 4...')